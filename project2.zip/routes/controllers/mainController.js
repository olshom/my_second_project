const showMain = ({ render }) => {
  render("main.eta");
};

export { showMain };
